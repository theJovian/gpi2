drop schema if exists demo;
drop table if exists users;
